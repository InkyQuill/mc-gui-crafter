# MCGUI Crafter brand kit

![Brand preview](preview.png)

## Production assets

This kit contains the refined assets used by the application.

Editable source files live in [`assets/branding`](README.md):

- [Application icon](app-icon.svg): dark tile with transparent corners.
- [Transparent color mark](logo-mark.svg): for dark backgrounds.
- [Monochrome mark](logo-mono.svg): `currentColor` for inline SVG.
- [PNG icons, 16–1024 px](png/).

The mark is a C built from seven identical stepped cells. The top-right cell is amber. Keep the cells square, spacing equal, and the middle/right area empty. Do not stretch, rotate, add gradients, or change the selected cell. Use the tile on light surfaces, or a dark monochrome mark. Use an empty alt attribute beside the visible application name; use `alt="MCGUI Crafter"` when the logo alone identifies the application.

| Color | Hex | Role |
| --- | --- | --- |
| Charcoal | `#1c2129` | Application tile |
| Mint | `#65faa5` | Six cells |
| Amber | `#feac23` | Top-right cell |

